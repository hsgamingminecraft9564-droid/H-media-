# H Media Player — 100-language Android starter

Contains a 100-entry language catalogue (native names + BCP-47 tags), an Android locale-config resource, English picker labels, and an AppCompat per-app locale controller.

## Important limitation
This is an integration starter, NOT 100 completed UI translations. Your existing VLC-derived strings and all app screens still need professionally reviewed translations. Missing translations fall back to default `res/values/strings.xml` (English).

## Integration
1. Merge `app/src/main/res/values/strings.xml` entries into your existing default strings file; do not overwrite existing strings.
2. Copy `app/src/main/res/xml/locales_config.xml` into your app module's `src/main/res/xml/`.
3. Copy `AppLanguage.kt` into the matching package path. Change its package declaration if your app namespace differs.
4. Merge `android:localeConfig="@xml/locales_config"` and `android:supportsRtl="true"` into the existing `<application>` element.
5. Confirm AndroidX AppCompat and Core dependencies exist. This controller requires `androidx.appcompat:appcompat` and `androidx.core:core-ktx`; use versions compatible with your current project.
6. Build the language screen from `AppLanguage.supported`. Show `nativeName` and call `AppLanguage.setLanguage(selected.tag)`. For System default call `AppLanguage.setLanguage(null)`.
7. Test app restart, Android Settings > App language (Android 13+), RTL layout, and fallback behavior.

## Notes
- AppCompatDelegate handles per-app locales on supported Android versions and integrates with Android 13+ system app-language settings when configured correctly.
- Audit your Activity recreation behavior and hard-coded left/right layout attributes.
- BCP-47 tags are used. Some resource folder qualifiers require `values-b+zh+Hans` style naming.
- This package has not been compiled against your repository. A real build/runtime test is still required.
