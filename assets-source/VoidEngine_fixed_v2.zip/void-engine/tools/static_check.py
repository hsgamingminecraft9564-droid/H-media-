#!/usr/bin/env python3
"""Lightweight static checks (no Kotlin compiler needed): bracket balance, package/dir match,
internal import resolution, duplicate top-level names, interface-implementation completeness."""
import os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "voidengine", "src")
problems = []
files = {}
for base, _, names in os.walk(ROOT):
    for n in names:
        if n.endswith(".kt"):
            p = os.path.join(base, n)
            files[p] = open(p, encoding="utf-8").read()

def strip_code(src):
    """Remove comments and string/char literal CONTENT so brackets inside them are ignored."""
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            while i < n and src[i] != "\n": i += 1
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2); i = n if j < 0 else j + 2
        elif src.startswith('"""', i):
            j = src.find('"""', i + 3)
            while j >= 0 and j + 3 < n and src[j + 3] == '"': j += 1
            i = n if j < 0 else j + 3; out.append('""')
        elif c == '"':
            i += 1
            while i < n and src[i] != '"':
                if src[i] == "\\": i += 1
                i += 1
            i += 1; out.append('""')
        elif c == "'":
            j = i + 1
            if j < n and src[j] == "\\": j += 2
            else: j += 1
            i = j + 1; out.append("''")
        else:
            out.append(c); i += 1
    return "".join(out)

top_level = {}  # (package, name) -> file
decl = re.compile(r"^(?:(?:public|internal|private|data|sealed|enum|abstract|open|annotation|inline|value|fun)\s+)*(?:class|interface|object)\s+(\w+)|^(?:private\s+|internal\s+)?(?:fun|val|var|typealias)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)", re.M)

for p, src in files.items():
    code = strip_code(src)
    for open_, close in ("()", "{}", "[]"):
        if code.count(open_) != code.count(close):
            problems.append(f"{os.path.relpath(p, ROOT)}: unbalanced {open_}{close} ({code.count(open_)} vs {code.count(close)})")
    # nesting order check
    stack = []
    pairs = {")": "(", "}": "{", "]": "["}
    for ch in code:
        if ch in "({[": stack.append(ch)
        elif ch in ")}]":
            if not stack or stack.pop() != pairs[ch]:
                problems.append(f"{os.path.relpath(p, ROOT)}: bracket nesting error"); break
    m = re.search(r"^package\s+([\w.]+)", src, re.M)
    if not m:
        problems.append(f"{os.path.relpath(p, ROOT)}: missing package"); continue
    pkg = m.group(1)
    rel = os.path.relpath(os.path.dirname(p), ROOT).split(os.sep)
    expected = ".".join(rel[2:])  # drop main|test, java
    if pkg != expected:
        problems.append(f"{os.path.relpath(p, ROOT)}: package {pkg} != directory {expected}")
    for mm in decl.finditer(src):
        name = mm.group(1) or mm.group(2)
        if name:
            key = (pkg, name)
            if key in top_level and top_level[key] != p and "/test/" not in p:
                problems.append(f"duplicate top-level name {name} in {pkg}")
            top_level[key] = p
    if "\t" in src: problems.append(f"{os.path.relpath(p, ROOT)}: contains tab characters")

internal = re.compile(r"^import\s+(com\.yourpackage\.engine[\w.]*)\.(\w+)(?:\s+as\s+\w+)?\s*$", re.M)
for p, src in files.items():
    for mm in internal.finditer(src):
        pkg, name = mm.group(1), mm.group(2)
        if (pkg, name) not in top_level:
            problems.append(f"{os.path.relpath(p, ROOT)}: import {pkg}.{name} not found")

def members(src, iface):
    m = re.search(r"interface\s+%s\s*\{" % iface, src)
    start = m.end(); depth = 1; i = start
    while depth:
        depth += {"{": 1, "}": -1}.get(src[i], 0); i += 1
    body = src[start:i - 1]
    # remove nested interface bodies (Listener)
    body = re.sub(r"interface\s+\w+\s*\{[^{}]*\}", "", body)
    funs = set(re.findall(r"\bfun\s+(\w+)\s*\(", body))
    props = set(re.findall(r"\b(?:val|var)\s+(\w+)\s*:", body))
    return funs, props

def text_of(name):
    for p, s in files.items():
        if os.path.basename(p) == name: return s
    raise SystemExit("missing " + name)

def check_impl(iface_file, iface, impl_file):
    funs, props = members(text_of(iface_file), iface)
    impl = text_of(impl_file)
    for f in funs:
        if not re.search(r"override\s+fun\s+%s\s*\(" % f, impl):
            problems.append(f"{impl_file}: missing override fun {f} of {iface}")
    for pr in props:
        if not re.search(r"override\s+(?:val|var)\s+%s\b" % pr, impl):
            problems.append(f"{impl_file}: missing override property {pr} of {iface}")

for impl in ("VlcBackendAdapter.kt", "Media3BackendAdapter.kt", "NativeBackendAdapter.kt", "Fakes.kt"):
    check_impl("BackendAdapter.kt", "BackendAdapter", impl)
check_impl("VoidEngine.kt", "VoidEngine", "VoidEngineImpl.kt")
check_impl("AudioGuard.kt", "AudioGuard", "AndroidAudioGuard.kt")
check_impl("AudioGuard.kt", "AudioGuard", "Fakes.kt")

# nested Listener interface
src = text_of("BackendAdapter.kt")
lm = re.search(r"interface\s+Listener\s*\{(.*?)\n    \}", src, re.S)
listener_funs = set(re.findall(r"fun\s+(\w+)\s*\(", lm.group(1)))
eng = text_of("VoidEngineImpl.kt")
for f in listener_funs:
    if not re.search(r"override\s+fun\s+%s\s*\(" % f, eng):
        problems.append(f"VoidEngineImpl.kt: Listener.{f} not implemented")
cb = re.search(r"interface\s+Callback\s*\{(.*?)\n    \}", text_of("AudioGuard.kt"), re.S)
for f in set(re.findall(r"fun\s+(\w+)\s*\(", cb.group(1))):
    if not re.search(r"override\s+fun\s+%s\s*\(" % f, eng):
        problems.append(f"VoidEngineImpl.kt: AudioGuard.Callback.{f} not implemented")

# enum exhaustiveness for PlaybackState when-expressions that have no else
states = set(re.findall(r"\b([A-Z_]+)\b", re.search(r"enum class PlaybackState\s*\{([^}]*)\}", text_of("PlaybackState.kt")).group(1)))
for fname in ("VoidEngineImpl.kt", "VoidPlayer.kt"):
    s = text_of(fname)
    for wm in re.finditer(r"when \((?:s\.state|state)\) \{(.*?)\n        \}\n", s, re.S):
        used = set(re.findall(r"PlaybackState\.([A-Z_]+)", wm.group(1)))
        if "else ->" not in wm.group(1) and used and used != states and "builder.setPlaybackState" not in s[max(0, wm.start()-80):wm.start()]:
            pass
print("files checked:", len(files))
if problems:
    print("PROBLEMS:")
    for q in problems: print(" -", q)
    sys.exit(1)
print("static check: OK")
