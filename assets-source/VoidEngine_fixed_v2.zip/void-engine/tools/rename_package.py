#!/usr/bin/env python3
"""Usage: python3 tools/rename_package.py com.hmedia.player.engine
Renames the engine package everywhere (sources, tests, manifest, Gradle namespace, docs)."""
import os, re, shutil, sys

OLD = "com.yourpackage.engine"
if len(sys.argv) != 2 or not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", sys.argv[1]):
    sys.exit("Give a valid new package, e.g. com.hmedia.player.engine (lower-case, no Java keywords like 'void').")
NEW = sys.argv[1]
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")

for base, _, files in os.walk(root):
    for name in files:
        if name.endswith((".kt", ".kts", ".xml", ".md", ".pro", ".snippet", ".sh")):
            path = os.path.join(base, name)
            text = open(path, encoding="utf-8").read()
            if OLD in text:
                open(path, "w", encoding="utf-8").write(text.replace(OLD, NEW))

for source_set in ("main", "test"):
    src = os.path.join(root, "voidengine", "src", source_set, "java", *OLD.split("."))
    dst = os.path.join(root, "voidengine", "src", source_set, "java", *NEW.split("."))
    if os.path.isdir(src) and src != dst:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
        parent = os.path.dirname(src)
        while parent != os.path.join(root, "voidengine", "src", source_set, "java"):
            try:
                os.rmdir(parent)
            except OSError:
                break
            parent = os.path.dirname(parent)
print("Renamed", OLD, "->", NEW)
