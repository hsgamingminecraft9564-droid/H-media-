#!/usr/bin/env bash
# Phase 1: audit + protect your existing app. Run from the ROOT of your Android project (not this zip).
# Usage: bash phase1_audit.sh
set -u
OUT="void_audit_$(date +%Y%m%d_%H%M%S).txt"

echo "== VOID Engine Phase 1 audit ==" | tee "$OUT"

echo -e "\n[1] Playback-related files" | tee -a "$OUT"
grep -rIl --include=*.kt --include=*.java -E "VoidEngine|libvlc|LibVLC|MediaPlayer|ExoPlayer|AudioManager|MediaSession" . 2>/dev/null | sort | tee -a "$OUT"

echo -e "\n[2] Direct VLC dependencies / API calls (these must move into VlcBackendAdapter)" | tee -a "$OUT"
grep -rIn --include=*.kt --include=*.java -E "org\.videolan|LibVLC|vlcVout|\.setMedia\(|IVLCVout" . 2>/dev/null | tee -a "$OUT"

echo -e "\n[3] Reliability smells (Phase 4 targets)" | tee -a "$OUT"
grep -rIn --include=*.kt --include=*.java -E "requestAudioFocus|abandonAudioFocus|AUDIOFOCUS_|reconnect|Handler\(|postDelayed|Thread\(" . 2>/dev/null | tee -a "$OUT"

echo -e "\n[4] Git backup" | tee -a "$OUT"
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git status --short | tee -a "$OUT"
  TAG="pre-void-engine-$(date +%Y%m%d)"
  git tag -f "$TAG" >/dev/null 2>&1 && echo "Tag created: $TAG" | tee -a "$OUT"
  git checkout -b void-engine-migration 2>&1 | tee -a "$OUT"
else
  echo "Not a git repository. Copy the whole project folder somewhere safe before you edit anything." | tee -a "$OUT"
fi

echo -e "\n[5] Clean debug build" | tee -a "$OUT"
if [ -x ./gradlew ]; then
  ./gradlew assembleDebug 2>&1 | tail -n 25 | tee -a "$OUT"
else
  echo "No ./gradlew here. Build with Android Studio: Build > Make Project." | tee -a "$OUT"
fi

echo -e "\nReport saved to $OUT. Now fill in docs/PHASE1_AUDIT.md: current features and known bugs." | tee -a "$OUT"
