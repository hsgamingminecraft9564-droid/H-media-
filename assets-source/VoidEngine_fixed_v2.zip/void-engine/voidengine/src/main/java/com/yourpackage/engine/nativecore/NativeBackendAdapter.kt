package com.yourpackage.engine.nativecore

import android.view.SurfaceView
import com.yourpackage.engine.BackendAdapter
import com.yourpackage.engine.BackendCapabilities
import com.yourpackage.engine.BackendNames
import com.yourpackage.engine.BackendProvider
import com.yourpackage.engine.EqualizerSettings
import com.yourpackage.engine.PlaybackError
import com.yourpackage.engine.PlaybackSource
import com.yourpackage.engine.TrackInfo

/**
 * Phase 7 extension point for your own demuxer / MediaCodec / FFmpeg pipeline.
 * Today it is an honest placeholder: it declares NO supported source types, so the selector never
 * picks it, and if you force it via preferredBackend it reports UnsupportedFormat and the engine
 * falls back to the next backend. Replace components one at a time (see docs/PHASE7_NATIVE.md),
 * widen [provider]'s capabilities as each one passes the shared acceptance tests.
 */
class NativeBackendAdapter : BackendAdapter {
    override var listener: BackendAdapter.Listener? = null

    override fun setSource(source: PlaybackSource) {
        listener?.onError(PlaybackError.UnsupportedFormat("Native backend has no components yet"))
    }

    override fun prepare() = Unit
    override fun play() = Unit
    override fun pause() = Unit
    override fun stop() = Unit
    override fun seekTo(positionMs: Long) = Unit
    override fun setPlaybackSpeed(speed: Float) = Unit
    override fun setVolume(volume: Float) = Unit
    override fun selectAudioTrack(id: String?) = Unit
    override fun selectSubtitleTrack(id: String?) = Unit
    override fun setEqualizer(settings: EqualizerSettings?) = Unit
    override fun equalizerBandFrequenciesHz(): List<Int> = emptyList()
    override fun attachVideoView(view: SurfaceView) = Unit
    override fun detachVideoView() = Unit
    override fun release() {
        listener = null
    }

    companion object {
        fun provider(): BackendProvider = BackendProvider(
            BackendCapabilities(
                name = BackendNames.NATIVE,
                supportedTypes = emptySet(),
                features = emptySet()
            )
        ) { NativeBackendAdapter() }
    }
}
