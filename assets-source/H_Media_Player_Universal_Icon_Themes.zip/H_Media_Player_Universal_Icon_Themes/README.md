# H Media Player — Universal Icon Themes

**374 original media-player and app UI icons × 7 selectable visual themes.**

Themes:
1. Modern Glass
2. Apple-inspired (original assets; not Apple trademarks or copied artwork)
3. Minecraft Block (original pixel/block-inspired artwork; not Minecraft assets)
4. Medieval Touch
5. Neon Cyber
6. Material Clean
7. Retro Arcade

Formats:
- SVG: editable vector artwork, 128×128
- PNG: rendered at 256×256
- Android Vector Drawable XML: native scalable vector resources, 24dp

Folder layout:
- `SVG/<Theme>/`
- `PNG/<Theme>/`
- `Android_Vector_Drawable_XML/` — theme-prefixed XML names
- `themes.json` — labels and descriptions for a theme picker

Android integration:
Copy the chosen theme's XML files into `app/src/main/res/drawable/`, or use the prefixed resource names directly after copying. For example, `modern_glass_ic_play.xml` becomes `@drawable/modern_glass_ic_play`.

A simple theme picker can read `themes.json` or use the theme IDs as app preferences. This pack contains assets and theme metadata; the actual in-app theme switching still needs to be connected in the app code.

All icons are original generic media UI symbols. Apple and Minecraft are used only to describe broad visual inspiration, not to imply affiliation or reproduce their proprietary icon sets.
