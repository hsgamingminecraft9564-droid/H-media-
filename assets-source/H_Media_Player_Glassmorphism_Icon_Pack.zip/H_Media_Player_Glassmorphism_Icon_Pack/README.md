# H Media Player — Glassmorphism Icon Pack

Original glass-style media-player icon assets.

## Included
- 53 SVG icons (128×128, editable vector source)
- 53 PNG icons (256×256)
- 53 Android Vector Drawable XML files (24dp)
- H Media Player launcher artwork (SVG + PNG sizes)
- Android adaptive launcher icon XML resources

## Visual system
Dark navy glass tiles, translucent cyan/violet/pink gradients, soft glass edge highlights, and white line glyphs.

## Android integration
1. Copy `Android_Vector_Drawable_XML/ic_*.xml` into `app/src/main/res/drawable/`.
2. Reference an icon in XML with `@drawable/ic_play`, or in Kotlin/Java with `R.drawable.ic_play`.
3. Copy the contents of `Android_Resources` into `app/src/main/res/` to use the adaptive launcher XML. Keep the `values` and `drawable` folders and merge rather than overwrite existing resources.
4. For launcher density PNGs, use Android Studio's Image Asset tool or place appropriately sized PNGs in mipmap density folders.

## Naming
SVG/PNG use names such as `play.svg` and `play.png`; Android XML uses `ic_play.xml`.

## Notes
The SVG and PNG files are glass-tile presentation assets. Android Vector Drawable XML files are transparent white glyphs intended for tinting or placement over your app's own glass UI surfaces. The launcher foreground is designed to be paired with the included dark background.
